# Job Search Project — Agent Handoff Document

**Last updated:** 2026-06-20  
**Workspace:** `/home/mcr040rcm/Jobs`  
**Server:** `mcr040rcm@10.0.5.242` (Docker container on AWS Ubuntu 20.04, SSH from `108.4.27.158`)  
**User:** PhD Epidemiology, MPH, postdoc — seeking remote US research/HEOR/medical writing/adjunct roles

---

## 1. Mission (current objective)

The goal is **not** to return a shortlist of “best picks.” The goal is:

1. **Maximize employer search coverage** across the full employer universe (~954 unique targets).
2. **Surface every realistic remote opportunity** matching the user’s background.
3. Maintain a **complete, deduplicated inventory** in `current_results.csv`.
4. **Exclude** anything already applied or previously rejected.

**Success metric:** Coverage percentage toward the highest technically achievable level — not “finding 5 jobs.”

---

## 2. Where we are now

| Metric | Value |
|--------|------:|
| Employers in master database | 1,523 |
| Unique deduped search targets | 954 |
| Employers searched (Round 23 API) | 142 |
| Employers recovered (Phase 3B HTTP) | 45 |
| **Combined coverage** | **187 / 954 (19.6%)** |
| Employers still failed | 835 (after Phase 3B) |
| Browser-recoverable (estimated) | ~514 |
| URL-dead / needs audit | ~354 |
| **Authoritative inventory** | **62 roles** in `current_results.csv` |
| Applied jobs | 22 roles (21 employers + duplicates) |
| Master seen URLs | 530+ |

### Tier breakdown (`current_results.csv`)

| Tier | Count | Meaning |
|------|------:|---------|
| Tier 1 | 42 | Direct IC — likely competitive |
| Tier 2 | 13 | Reasonable stretch |
| Tier 3 | 7 | Unlikely but possible |

### Phase history summary

| Phase | What it did | Outcome |
|-------|-------------|---------|
| **Phase 2c / 3** | Broad API/HTML employer search | Large raw inventory; keyword-inflated scoring |
| **Phase 4** | Strict re-score + dedupe | Reduced to realistic 62-role inventory; fixed broken Tier A labels |
| **Round 22** | Full employer API pass | Partial coverage |
| **Round 23** | Full API search of 954 deduped employers (~2.3 hr) | 142 searched, 812 failed, 84 raw qualifying → 60 actionable after Phase 4 merge |
| **Phase 3B** | HTTP Workday tenant recovery on 880 failed employers | +45 searched, +2 net-new roles; **HTTP exhausted** |
| **Phase 3C** | **PLANNED — NOT STARTED** | GUI/browser recovery required; queue prepared |

---

## 3. Directory rules (strict)

**Root `/home/mcr040rcm/Jobs/` may contain ONLY:**

- `employer_database_master.csv`
- `current_results.csv`
- `applied_jobs.csv`
- `master_seen_jobs.csv`
- Personal docs (resume, transcripts, cover letter)

**Everything else goes in:**

| Path | Purpose |
|------|---------|
| `/archives/` | Historical run CSVs, audits |
| `/archives/runs/` | `remote_job_matches_*.csv` |
| `/runs/` | Checkpoints, coverage JSON, queues |
| `/logs/` | Run logs |
| `/scripts/` | Python search/rescore scripts |
| `/employer_database/` | Coverage reports, audits, plans |

No round reports, temp CSVs, or audit files in root.

---

## 4. Authoritative files

| File | Role |
|------|------|
| `employer_database_master.csv` | 1,523 employers with career URLs, ATS, category |
| `current_results.csv` | **Single source of truth** for actionable inventory (62 roles) |
| `applied_jobs.csv` | 22 applied roles — never show again |
| `master_seen_jobs.csv` | All URLs ever encountered |
| `scripts/exclusion_lists.json` | Applied URLs + rejected URLs for dedup |
| `scripts/phase4_audit_rescore.py` | Re-score all historical CSVs → rebuild `current_results.csv` |
| `scripts/round23_complete_search.py` | Round 23 full API search |
| `scripts/phase3b_browser_recovery.py` | Phase 3B HTTP recovery (do not re-run on this server) |
| `runs/round23_search_audit_20260620.json` | Round 23 per-employer log |
| `runs/phase3b_coverage_20260620.json` | Phase 3B per-employer log (880 entries) |
| `runs/phase3c_browser_queue_20260620.json` | **Phase 3C priority queue** (835 failed employers) |
| `employer_database/phase3b_coverage_report.md` | Phase 3B results |
| `employer_database/phase3c_gui_recovery_plan.md` | Phase 3C setup plan |
| `archives/audits/employer_accessibility_audit_20260617.csv` | 773 employers with fetch status, final_url |
| `archives/runs/remote_job_matches_round23_20260620.csv` | Round 23 raw matches |
| `archives/runs/remote_job_matches_phase3b_20260620.csv` | Phase 3B raw matches (5 after applied filter) |

---

## 5. Search criteria (apply to all phases)

### Remote filter (strict)

**Accept:** fully remote, remote anywhere in US, remote with occasional/quarterly/annual travel.

**Reject:** hybrid, office attendance, remote within commuting distance, weekly office presence, 50% travel.

Phase 4 uses the strictest gate — title + `remote_status` field must affirm US remote. Do not infer remote from job description alone.

### Target roles

**Primary:** Epidemiologist, Research Scientist/Associate/Analyst, Health Services Research, Program Evaluation, HEOR, RWE, Outcomes Research, Medical/Scientific Writer, Medical Communications, Healthcare Analytics, Population Health Analytics, Clinical Data Analyst, Public Health Analyst, Biostatistician, Quantitative Analyst, Evidence Synthesis.

**Secondary:** Data Analyst, Healthcare Data Scientist, Quality Measurement Analyst, Federal Research Contractor roles, Remote Adjunct/Lecturer/Instructor/Faculty.

**Include all employment types:** full-time, part-time, contract, consulting, adjunct, lecturer, temporary research appointments.

### Seniority filter

**Target:** Associate, Analyst, Scientist, Researcher, Epidemiologist, Medical Writer, Consultant, Senior Analyst/Scientist/Researcher.

**Do not auto-exclude:** Senior, Principal (evaluate individually).

**Exclude:** VP, Vice President, Head of, Executive Director, Medical Director, Global Lead, General Manager. Associate Director and Director — evaluate case by case; exclude if management is core requirement.

### Deduplication

Never show:
- Anything in `applied_jobs.csv`
- Anything in `exclusion_lists.json` rejected URLs
- Exact duplicate URLs

If a posting materially changed: mark **REPOSTED / UPDATED**.

---

## 6. Applied jobs (22 — do not resurface)

| Employer | Title |
|----------|-------|
| SimulStat | Epidemiologist |
| Simmons University | MPH Online - Section Instructor (Adjunct Faculty) |
| Midi Health | Healthcare Data Analyst |
| Precision Medicine Group | Medical Writer, Medical Communications |
| AIR | Medicaid Researcher, Healthcare Innovations |
| Tuesday Health | Data Analyst, Clinical Operations |
| DLH Corporation | Programmer Analyst (SAS or R) |
| Guidehouse | Healthcare Claims Analytics Senior Consultant |
| Ohio State (Health Outcomes) | Law Enforcement Administration and Policy Research Scientist |
| Viatris | Director, Medical Outcomes Research |
| AIR | Research Associate, Healthcare Innovations |
| Precision AQ | Associate Research Scientist, Evidence Generation |
| Precision Medicine Group | Associate Research Scientist, Evidence Generation |
| AIR | Medicaid and Medicare Policy Researcher |
| CDC Foundation | Epidemiologist – eCR Evaluation |
| CVP | Research & Evaluation Quantitative Analyst |
| Dandelion Health | Health Economist and Outcomes Researcher |
| RTI International | Health Outcomes Researcher |
| IQVIA | Epidemiologist, Vaccines (FSP) |
| Exact Sciences | Clinical Biostatistician I |
| DLH Corporation | Research Analyst (SAS and R) |
| DLH Corporation | Research Analyst (Non-Data) |

Full URLs in `applied_jobs.csv` and `scripts/exclusion_lists.json`.

---

## 7. Phase 3B results (completed — do not repeat)

**Script:** `scripts/phase3b_browser_recovery.py`  
**Log:** `logs/phase3b_run.log`  
**Runtime:** ~23 minutes, 880/880 employers processed

| Result | Count |
|--------|------:|
| Employers recovered (HTTP Workday/API) | 45 |
| Still failed | 835 |
| Postings reviewed | 945 |
| Raw qualifying roles | 7 |
| Net-new in `current_results.csv` | 2 |

**Recovery methods that worked:**
- `http_wd_embed`: 34 (Workday CXS API via embedded tenant discovery)
- `http_html_scrape`: 8
- `http_wd_guess`: 2
- `http_gh_slug`: 1

**Net-new roles added via Phase 4 merge:**
1. **Alignment Health** — Principal AI & Data Scientist (Remote) — Tier 2
2. **Mirati Therapeutics (BMS)** — Principal Research AI Innovation Lead — Tier 2

**Top failure reasons (835):**
- `no_matching_roles` / no API access: 327
- DNS dead URL: 244
- Bot protection (403): 108
- 404 dead URL: 80
- SSL certificate errors: 37

**Known issue:** Checkpoint file `runs/phase3b_checkpoint_20260620.json` was partially corrupted by an overlapping run (index shows 70 with bad roles). **Authoritative Phase 3B data is in `runs/phase3b_coverage_20260620.json`**, not the checkpoint.

---

## 8. Phase 3C — NEXT STEP (not started)

### Critical constraint

**Do NOT run another HTTP-only search on this server.** Phase 3B proved diminishing returns (15% → 19.6% coverage).

### Environment blockers on this server

| Check | Result |
|-------|--------|
| Playwright Chromium | FAIL — SIGTRAP (Docker seccomp) |
| Playwright Firefox | FAIL |
| Xvfb + Playwright | FAIL — same SIGTRAP |
| DISPLAY / desktop | Not available |

### Playwright MCP (configured 2026-06-20)

**Config file:** `~/.cursor/mcp.json`
```json
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": ["-y", "@playwright/mcp@latest"]
    }
  }
}
```

**CLI enable steps:**
```bash
agent mcp enable playwright    # already run once; shows "playwright: ready"
agent mcp list                 # verify status
agent mcp list-tools playwright
```

**Start fresh session** (MCP loads at session start — do not use `--resume` for first MCP test):
```bash
agent                          # new session
# or one-shot:
agent --approve-mcps -p "navigate to https://example.com and snapshot"
```

**Important:** MCP server can show `ready` on this server, but **browser launch may still fail** inside Docker. If browser tools crash, run the agent from **local Cursor desktop** with Remote SSH to this server so the browser runs locally.

### Phase 3C queue

**File:** `runs/phase3c_browser_queue_20260620.json`  
**Total:** 835 failed employers  
**Browser-recoverable:** 514  

**Priority order:**
1. Workday (443)
2. Custom portals (130)
3. Phenom (26)
4. iCIMS (23)
5. Federal/USAJobs (41)
6. University (9)
7. Hospital/academic (21)
8. Other (Taleo, Oracle, Greenhouse, etc.)

### Mark employer as searched ONLY if:

1. API/backend search succeeded, **OR**
2. GUI/browser was opened and searched via UI, **OR**
3. Site is blocked (CAPTCHA/login/bot/dead URL) and reason is documented

**API failure alone is NOT sufficient** to mark searched.

### Phase 3C browser protocol

For each employer in queue:
1. Open career URL in browser (via Playwright MCP).
2. Wait for JS-rendered jobs.
3. Search: epidemiologist, research scientist, HEOR, RWE, outcomes research, medical writer, public health, biostatistician, health services research, program evaluation, data analyst, remote.
4. Apply remote/location filters via UI.
5. Paginate; open relevant postings.
6. Extract title, location, remote status, salary, URL, posting date.
7. Apply Phase 4 remote/seniority filters.
8. Append qualifying roles to output CSV.
9. Log status in coverage JSON.

**Do not bypass CAPTCHA, login walls, or bot protection.** Mark as `blocked` with reason.

### Phase 3C outputs (when complete)

Write to subdirectories only:
- `archives/runs/remote_job_matches_phase3c_YYYYMMDD.csv`
- `runs/phase3c_coverage_YYYYMMDD.json`
- `employer_database/phase3c_coverage_report.md`
- `logs/phase3c_run.log`

Then merge via:
```bash
python3 /home/mcr040rcm/Jobs/scripts/phase4_audit_rescore.py
```

---

## 9. Key scripts reference

| Script | Purpose | Re-run? |
|--------|---------|---------|
| `phase4_audit_rescore.py` | Rebuild `current_results.csv` from all archive CSVs | Yes — after any new discovery |
| `round23_complete_search.py` | Full Round 23 API search | No — completed |
| `phase3b_browser_recovery.py` | HTTP Workday recovery | **No — exhausted on this server** |
| `phase2c_full_universe_search.py` | Earlier broad search | No — superseded |
| `phase3_complete_inventory.py` | Earlier inventory build | No — superseded |
| `round22_complete_search.py` | Earlier round | No — superseded |

---

## 10. Round 23 failure breakdown (baseline for Phase 3C)

Round 23 searched 142 / 954 employers via API. Top ATS failures:

| ATS | Failures (approx) |
|-----|------:|
| Workday embedded/blocked API | 442 |
| Custom portals | 128 |
| Greenhouse slug mismatch | 32 |
| Phenom | 18 |
| iCIMS | 17 |
| USAJobs | 15 |
| Oracle/Taleo | 12 |

Phase 3B recovered 45 Workday-classified employers via HTTP tenant discovery that Round 23 missed (e.g., IQVIA Workday tenant works when career page fetch failed).

---

## 11. Output format for roles

For every qualifying role include:

- Employer
- Title
- Employment type
- Remote status
- Salary (if available)
- ATS
- Posting date
- Fit score / competitiveness tier
- Recruiter screen probability
- First interview probability
- Key strengths (`why_match`)
- Key risks
- URL

**Return ALL qualifying roles — no caps at 10 or 25.**

---

## 12. Environment notes

- **Not a git repo** at workspace root.
- Shell sometimes hits `EAGAIN`/fork limits — retry after brief wait.
- Playwright installed at `~/.local/lib/python3.9/site-packages/playwright`.
- Chromium binary at `~/.cache/ms-playwright/` — launches fail with SIGTRAP in Docker.
- `playwright install-deps` requires root — not available.
- CLI config: `~/.cursor/cli-config.json` (`approvalMode: unrestricted`).
- Agent transcript for full conversation history:  
  `/home/mcr040rcm/.cursor/projects/home-mcr040rcm/agent-transcripts/5af6888e-4795-49a1-aec4-89b256c3a533/5af6888e-4795-49a1-aec4-89b256c3a533.jsonl`

---

## 13. Immediate next actions for new agent

1. **Verify Playwright MCP** in a fresh CLI session:
   ```bash
   agent mcp list
   agent --approve-mcps -p "Navigate to https://example.com and take a browser snapshot"
   ```
2. If browser works → **start Phase 3C** against `runs/phase3c_browser_queue_20260620.json` (Workday first).
3. If browser fails (SIGTRAP) → **stop** and instruct user to run from local Cursor desktop via Remote SSH.
4. **Do not** re-run `phase3b_browser_recovery.py` or Round 23 API search.
5. After Phase 3C batch → run `phase4_audit_rescore.py` to merge into `current_results.csv`.
6. Write coverage report to `employer_database/phase3c_coverage_report.md`.
7. Keep root directory clean.

---

## 14. User preferences (important)

- Benefits are **not** a major decision factor — include part-time, contract, adjunct, lecturer roles.
- Goal is **complete inventory**, not ranked shortlists.
- Applied jobs stay in history but are excluded from results.
- Do not create git commits unless explicitly asked.
- Do not put markdown reports or temp files in root.

---

*End of handoff. Start with Phase 3C browser recovery when MCP browser tools are confirmed working.*
